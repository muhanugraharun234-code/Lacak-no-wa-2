package com.whatsapp.tracker;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText inputNumber;
    private Button btnTrack;
    private TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputNumber = findViewById(R.id.inputNumber);
        btnTrack = findViewById(R.id.btnTrack);
        resultText = findViewById(R.id.resultText);

        btnTrack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number = inputNumber.getText().toString();
                if (!number.isEmpty()) {
                    // Simulasi pelacakan (Logic bisa diganti dengan API nyata)
                    String status = "Online"; 
                    String location = "Jakarta, Indonesia (Simulasi)";
                    String lastSeen = "Baru saja";

                    resultText.setText("Nomor: " + number + "\nStatus: " + status + "\nLokasi: " + location + "\nTerakhir Dilihat: " + lastSeen);
                } else {
                    Toast.makeText(MainActivity.this, "Masukkan nomor!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
